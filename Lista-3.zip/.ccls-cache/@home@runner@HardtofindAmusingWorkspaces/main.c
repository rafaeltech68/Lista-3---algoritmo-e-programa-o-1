#include <stdio.h>
/*Terceira lista de exercícios
1. Faça um algoritmo que receba um número e mostre a mensagem "Sim" caso este número seja maior que 10. Se for menor ou igual, o programa deve encerrar sem exibir mais nada.
2. Solicite que o usuário digite um número. Informe então se este número é par ou impar.
3. Escrever um algoritmo que leia dois valores inteiro distintos e informe qual deles é o maior.4. Altere o exercicio anterior de forma que ele informe também se os números são iguais.5. Crie um programa que recebe um número inteiro e informa se este número é múltiplo de 10.
6. Crie um programa que recebe dois números inteiros. Exiba a mensagem "sim' apenas caso ambos sejam maiores que 10.
Desafio Jedi 7. Escreva um programa que converta um intervalo de tempo dado em segundos, em: horas, minutos e segundos. (Por exemplo, se o tempo dado for 3 850 segundos, o programa deve fornecer 1 h 4 min 10 s.)*/
/*int main(void) {
int numero;
printf("digite um numero: ");
scanf("%d", &numero);
if( numero > 10){
printf("sim");
}
return 0;
 }*/

int main(void){
  int numero;
  printf("digite um numero: ");
  scanf("%d", &numero);
  if(numero % 2 == 0){
    printf("par");
  }
  else{
    printf("impar");
  }
  return 0;
}